﻿namespace _152120221002_152120231154_prelab6_1_
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            this.guessTextBox = new System.Windows.Forms.TextBox();
            this.guessButton = new System.Windows.Forms.Button();
            this.wordLengthLabel = new System.Windows.Forms.Label();
            this.hiddenWordLabel = new System.Windows.Forms.Label();
            this.guessedLettersLabel = new System.Windows.Forms.Label();
            this.scoreLabel = new System.Windows.Forms.Label();
            this.hangmanPictureBox = new System.Windows.Forms.PictureBox();
            this.endButton = new System.Windows.Forms.Button();
            this.helpButton = new System.Windows.Forms.Button();
            this.timeLabel = new System.Windows.Forms.Label();
            this.settingsLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.hangmanPictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // guessTextBox
            // 
            this.guessTextBox.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guessTextBox.Location = new System.Drawing.Point(29, 682);
            this.guessTextBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guessTextBox.Name = "guessTextBox";
            this.guessTextBox.Size = new System.Drawing.Size(289, 34);
            this.guessTextBox.TabIndex = 0;
            // 
            // guessButton
            // 
            this.guessButton.BackColor = System.Drawing.Color.OliveDrab;
            this.guessButton.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guessButton.Location = new System.Drawing.Point(407, 663);
            this.guessButton.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guessButton.Name = "guessButton";
            this.guessButton.Size = new System.Drawing.Size(257, 70);
            this.guessButton.TabIndex = 1;
            this.guessButton.Text = "Guess";
            this.guessButton.UseVisualStyleBackColor = false;
            this.guessButton.Click += new System.EventHandler(this.guessButton_Click);
            // 
            // wordLengthLabel
            // 
            this.wordLengthLabel.AutoSize = true;
            this.wordLengthLabel.BackColor = System.Drawing.Color.Wheat;
            this.wordLengthLabel.Font = new System.Drawing.Font("Segoe UI", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.wordLengthLabel.Location = new System.Drawing.Point(47, 334);
            this.wordLengthLabel.Name = "wordLengthLabel";
            this.wordLengthLabel.Size = new System.Drawing.Size(109, 46);
            this.wordLengthLabel.TabIndex = 2;
            this.wordLengthLabel.Text = "label1";
            // 
            // hiddenWordLabel
            // 
            this.hiddenWordLabel.AutoSize = true;
            this.hiddenWordLabel.BackColor = System.Drawing.Color.Wheat;
            this.hiddenWordLabel.Font = new System.Drawing.Font("Segoe UI", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hiddenWordLabel.Location = new System.Drawing.Point(45, 181);
            this.hiddenWordLabel.Name = "hiddenWordLabel";
            this.hiddenWordLabel.Size = new System.Drawing.Size(142, 60);
            this.hiddenWordLabel.TabIndex = 3;
            this.hiddenWordLabel.Text = "label2";
            // 
            // guessedLettersLabel
            // 
            this.guessedLettersLabel.AutoSize = true;
            this.guessedLettersLabel.BackColor = System.Drawing.Color.Wheat;
            this.guessedLettersLabel.Font = new System.Drawing.Font("Segoe UI", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guessedLettersLabel.Location = new System.Drawing.Point(47, 542);
            this.guessedLettersLabel.Name = "guessedLettersLabel";
            this.guessedLettersLabel.Size = new System.Drawing.Size(112, 50);
            this.guessedLettersLabel.TabIndex = 4;
            this.guessedLettersLabel.Text = "______";
            // 
            // scoreLabel
            // 
            this.scoreLabel.AutoSize = true;
            this.scoreLabel.BackColor = System.Drawing.Color.Wheat;
            this.scoreLabel.Font = new System.Drawing.Font("Segoe UI", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.scoreLabel.Location = new System.Drawing.Point(1099, 733);
            this.scoreLabel.Name = "scoreLabel";
            this.scoreLabel.Size = new System.Drawing.Size(109, 46);
            this.scoreLabel.TabIndex = 5;
            this.scoreLabel.Text = "label4";
            // 
            // hangmanPictureBox
            // 
            this.hangmanPictureBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.hangmanPictureBox.Location = new System.Drawing.Point(756, 118);
            this.hangmanPictureBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.hangmanPictureBox.Name = "hangmanPictureBox";
            this.hangmanPictureBox.Size = new System.Drawing.Size(686, 472);
            this.hangmanPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.hangmanPictureBox.TabIndex = 6;
            this.hangmanPictureBox.TabStop = false;
            // 
            // endButton
            // 
            this.endButton.BackColor = System.Drawing.Color.Khaki;
            this.endButton.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.endButton.Location = new System.Drawing.Point(703, 663);
            this.endButton.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.endButton.Name = "endButton";
            this.endButton.Size = new System.Drawing.Size(257, 70);
            this.endButton.TabIndex = 7;
            this.endButton.Text = "End";
            this.endButton.UseVisualStyleBackColor = false;
            this.endButton.Click += new System.EventHandler(this.endButton_Click);
            // 
            // helpButton
            // 
            this.helpButton.BackColor = System.Drawing.Color.BurlyWood;
            this.helpButton.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.helpButton.Location = new System.Drawing.Point(427, 432);
            this.helpButton.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.helpButton.Name = "helpButton";
            this.helpButton.Size = new System.Drawing.Size(312, 65);
            this.helpButton.TabIndex = 9;
            this.helpButton.Text = "Clue?";
            this.helpButton.UseVisualStyleBackColor = false;
            this.helpButton.Click += new System.EventHandler(this.helpButton_Click);
            // 
            // timeLabel
            // 
            this.timeLabel.AutoSize = true;
            this.timeLabel.BackColor = System.Drawing.Color.Wheat;
            this.timeLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.timeLabel.Location = new System.Drawing.Point(1088, 663);
            this.timeLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.timeLabel.Name = "timeLabel";
            this.timeLabel.Size = new System.Drawing.Size(131, 31);
            this.timeLabel.TabIndex = 10;
            this.timeLabel.Text = "timeLabel";
            // 
            // settingsLabel
            // 
            this.settingsLabel.BackColor = System.Drawing.Color.Wheat;
            this.settingsLabel.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.settingsLabel.Location = new System.Drawing.Point(50, 45);
            this.settingsLabel.Name = "settingsLabel";
            this.settingsLabel.Size = new System.Drawing.Size(703, 46);
            this.settingsLabel.TabIndex = 11;
            this.settingsLabel.Text = "labelSettings";
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Wheat;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(1399, 892);
            this.Controls.Add(this.settingsLabel);
            this.Controls.Add(this.timeLabel);
            this.Controls.Add(this.helpButton);
            this.Controls.Add(this.endButton);
            this.Controls.Add(this.hangmanPictureBox);
            this.Controls.Add(this.scoreLabel);
            this.Controls.Add(this.guessedLettersLabel);
            this.Controls.Add(this.hiddenWordLabel);
            this.Controls.Add(this.wordLengthLabel);
            this.Controls.Add(this.guessButton);
            this.Controls.Add(this.guessTextBox);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Form2";
            ((System.ComponentModel.ISupportInitialize)(this.hangmanPictureBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox guessTextBox;
        private System.Windows.Forms.Button guessButton;
        private System.Windows.Forms.Label wordLengthLabel;
        private System.Windows.Forms.Label hiddenWordLabel;
        private System.Windows.Forms.Label guessedLettersLabel;
        private System.Windows.Forms.Label scoreLabel;
        private System.Windows.Forms.PictureBox hangmanPictureBox;
        private System.Windows.Forms.Button endButton;
        private System.Windows.Forms.Button helpButton;
        private System.Windows.Forms.Label timeLabel;
        private System.Windows.Forms.Label settingsLabel;
    }
}