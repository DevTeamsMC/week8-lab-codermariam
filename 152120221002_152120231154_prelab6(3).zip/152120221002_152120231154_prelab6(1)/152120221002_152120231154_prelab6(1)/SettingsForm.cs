﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _152120221002_152120231154_prelab6_1_
{
    public partial class SettingsForm : Form
    {
        public int GameTime { get; private set; }
        public string Difficulty { get; private set; }
        public string ImageStyle { get; private set; }

        public SettingsForm()
        {
            InitializeComponent();
            InitializeSettings();
        }

        private void InitializeSettings()
        {

            
            timeComboBox.Items.AddRange(new string[] { "30", "60", "90", "120" }); 
            timeComboBox.SelectedItem = "60";

            
            difficultyComboBox.Items.AddRange(new string[] { "Easy", "Medium", "Hard" });
            difficultyComboBox.SelectedItem = "Medium"; 

            
            imageComboBox.Items.AddRange(new string[] { "Hangman", "Falling Flowers", "Heart and Swords" }); 
            imageComboBox.SelectedItem = "Hangman"; // Set a default image style
        }

        private void saveButton_Click(object sender, EventArgs e)
        {
            if (timeComboBox.SelectedItem != null && difficultyComboBox.SelectedItem != null && imageComboBox.SelectedItem != null)
            {
                GameTime = int.Parse(timeComboBox.SelectedItem.ToString());
                Difficulty = difficultyComboBox.SelectedItem.ToString();
                ImageStyle = imageComboBox.SelectedItem.ToString();

                this.DialogResult = DialogResult.OK;
                this.Close();
            }
            else
            {
                MessageBox.Show("Please fill in all settings.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void cancelButton_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }
    }
}
