﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Net.Mime.MediaTypeNames;


namespace _152120221002_152120231154_prelab6_1_
{
    
    public partial class Form2 : Form
    {
        public class Question
        {
            public string Word { get; set; }
            public string Difficulty { get; set; } 
        }

        private string selectedWord;
      
        private string hiddenWord;
        private List<char> guessedLetters = new List<char>();
        private int score = 100;
        private int incorrectGuesses = 0;
        private int maxIncorrectGuesses = 10;
        private string category;
        private string gameStyle;
        private string gameDifficulty;
        private string imageStyle;
        private int settingsGameTime;
        //private string gameDifficulty;

        private Timer gameTimer;
        private int timeLeft = 10;
        private bool gameOver = false;

        private Dictionary<string, List<Question>> categoryQuestions = new Dictionary<string, List<Question>>()
        {
            { "History", new List<Question> {
                new Question { Word = "era", Difficulty = "Easy" },
                new Question { Word = "king", Difficulty = "Easy" },
                new Question { Word = "war", Difficulty = "Easy" },
                new Question { Word = "date", Difficulty = "Easy" },
                new Question { Word = "land", Difficulty = "Easy" },
                new Question { Word = "army", Difficulty = "Easy" },
                new Question { Word = "peace", Difficulty = "Easy" },
                new Question { Word = "power", Difficulty = "Easy" },
                new Question { Word = "city", Difficulty = "Easy" },
                new Question { Word = "rule", Difficulty = "Easy" },
                new Question { Word = "empire", Difficulty = "Medium" },
                new Question { Word = "revolution", Difficulty = "Medium" },
                new Question { Word = "pharaoh", Difficulty = "Medium" },
                new Question { Word = "monarchy", Difficulty = "Medium" },
                new Question { Word = "crusade", Difficulty = "Medium" },
                new Question { Word = "treaty", Difficulty = "Medium" },
                new Question { Word = "dynasty", Difficulty = "Medium" },
                new Question { Word = "colonial", Difficulty = "Medium" },
                new Question { Word = "renaissance", Difficulty = "Medium" },
                new Question { Word = "artifact", Difficulty = "Medium" },
                new Question { Word = "medieval", Difficulty = "Hard" },
                new Question { Word = "civilwar", Difficulty = "Hard" },
                new Question { Word = "constitution", Difficulty = "Hard" },
                new Question { Word = "imperialism", Difficulty = "Hard" },
                new Question { Word = "enlightenment", Difficulty = "Hard" },
                new Question { Word = "napoleon", Difficulty = "Hard" },
                new Question { Word = "pyramid", Difficulty = "Hard" },
                new Question { Word = "inquisition", Difficulty = "Hard" },
                new Question { Word = "armistice", Difficulty = "Hard" },
                new Question { Word = "regime", Difficulty = "Hard" }
            }},
            { "Geography", new List<Question> {
                new Question { Word = "sea", Difficulty = "Easy" },
                new Question { Word = "land", Difficulty = "Easy" },
                new Question { Word = "map", Difficulty = "Easy" },
                new Question { Word = "town", Difficulty = "Easy" },
                new Question { Word = "lake", Difficulty = "Easy" },
                new Question { Word = "river", Difficulty = "Easy" },
                new Question { Word = "coast", Difficulty = "Easy" },
                new Question { Word = "soil", Difficulty = "Easy" },
                new Question { Word = "port", Difficulty = "Easy" },
                new Question { Word = "city", Difficulty = "Easy" },
                new Question { Word = "continent", Difficulty = "Medium" },
                new Question { Word = "archipelago", Difficulty = "Medium" },
                new Question { Word = "volcano", Difficulty = "Medium" },
                new Question { Word = "glacier", Difficulty = "Medium" },
                new Question { Word = "peninsula", Difficulty = "Medium" },
                new Question { Word = "savanna", Difficulty = "Medium" },
                new Question { Word = "island", Difficulty = "Medium" },
                new Question { Word = "delta", Difficulty = "Medium" },
                new Question { Word = "rainforest", Difficulty = "Medium" },
                new Question { Word = "tundra", Difficulty = "Medium" },
                new Question { Word = "equator", Difficulty = "Hard" },
                new Question { Word = "latitude", Difficulty = "Hard" },
                new Question { Word = "longitude", Difficulty = "Hard" },
                new Question { Word = "mountain", Difficulty = "Hard" },
                new Question { Word = "desert", Difficulty = "Hard" },
                new Question { Word = "plateau", Difficulty = "Hard" },
                new Question { Word = "canyon", Difficulty = "Hard" },
                new Question { Word = "oasis", Difficulty = "Hard" },
                new Question { Word = "fjord", Difficulty = "Hard" },
                new Question { Word = "basin", Difficulty = "Hard" }
            }},
            { "Mathematics", new List<Question> {
                new Question { Word = "sum", Difficulty = "Easy" },
                new Question { Word = "plus", Difficulty = "Easy" },
                new Question { Word = "odd", Difficulty = "Easy" },
                new Question { Word = "even", Difficulty = "Easy" },
                new Question { Word = "zero", Difficulty = "Easy" },
                new Question { Word = "line", Difficulty = "Easy" },
                new Question { Word = "area", Difficulty = "Easy" },
                new Question { Word = "cube", Difficulty = "Easy" },
                new Question { Word = "root", Difficulty = "Easy" },
                new Question { Word = "base", Difficulty = "Easy" },
                new Question { Word = "algebra", Difficulty = "Medium" },
                new Question { Word = "geometry", Difficulty = "Medium" },
                new Question { Word = "calculus", Difficulty = "Medium" },
                new Question { Word = "matrix", Difficulty = "Medium" },
                new Question { Word = "vector", Difficulty = "Medium" },
                new Question { Word = "integral", Difficulty = "Medium" },
                new Question { Word = "derivative", Difficulty = "Medium" },
                new Question { Word = "logarithm", Difficulty = "Medium" },
                new Question { Word = "equation", Difficulty = "Medium" },
                new Question { Word = "function", Difficulty = "Medium" },
                new Question { Word = "variable", Difficulty = "Hard" },
                new Question { Word = "theorem", Difficulty = "Hard" },
                new Question { Word = "probability", Difficulty = "Hard" },
                new Question { Word = "fraction", Difficulty = "Hard" },
                new Question { Word = "polygon", Difficulty = "Hard" },
                new Question { Word = "angle", Difficulty = "Hard" },
                new Question { Word = "radius", Difficulty = "Hard" },
                new Question { Word = "pi", Difficulty = "Hard" },
                new Question { Word = "median", Difficulty = "Hard" },
                new Question { Word = "divisor", Difficulty = "Hard" }
            }},
            { "General Culture", new List<Question> {
                new Question { Word = "art", Difficulty = "Easy" },
                new Question { Word = "book", Difficulty = "Easy" },
                new Question { Word = "film", Difficulty = "Easy" },
                new Question { Word = "song", Difficulty = "Easy" },
                new Question { Word = "game", Difficulty = "Easy" },
                new Question { Word = "food", Difficulty = "Easy" },
                new Question { Word = "sport", Difficulty = "Easy" },
                new Question { Word = "city", Difficulty = "Easy" },
                new Question { Word = "name", Difficulty = "Easy" },
                new Question { Word = "cinema", Difficulty = "Medium" },
                new Question { Word = "literature", Difficulty = "Medium" },
                new Question { Word = "fashion", Difficulty = "Medium" },
                new Question { Word = "philosophy", Difficulty = "Medium" },
                new Question { Word = "painting", Difficulty = "Medium" },
                new Question { Word = "theater", Difficulty = "Medium" },
                new Question { Word = "music", Difficulty = "Medium" },
                new Question { Word = "opera", Difficulty = "Medium" },
                new Question { Word = "sculpture", Difficulty = "Medium" },
                new Question { Word = "mythology", Difficulty = "Medium" },
                new Question { Word = "festival", Difficulty = "Hard" },
                new Question { Word = "language", Difficulty = "Hard" },
                new Question { Word = "comedy", Difficulty = "Hard" },
                new Question { Word = "culture", Difficulty = "Hard" },
                new Question { Word = "journalism", Difficulty = "Hard" },
                new Question { Word = "poetry", Difficulty = "Hard" },
                new Question { Word = "media", Difficulty = "Hard" },
                new Question { Word = "internet", Difficulty = "Hard" },
                new Question { Word = "tradition", Difficulty = "Hard" },
                new Question { Word = "architecture", Difficulty = "Hard" }
            }}
        };

        private Dictionary<string, string> wordClues = new Dictionary<string, string>()
        {
            // History
            { "empire", "A group of countries under a single ruler" },
            { "revolution", "A major change in power or organizational structures" },
            { "pharaoh", "Egyptian king" },
            { "monarchy", "A government ruled by a king or queen" },
            { "crusade", "Medieval military expeditions" },
            { "treaty", "A formal agreement between countries" },
            { "dynasty", "Line of rulers from the same family" },
            { "colonial", "Relating to colonies" },
            { "renaissance", "A cultural rebirth" },
            { "artifact", "Historical object" },
            { "medieval", "Relating to the Middle Ages" },
            { "civilwar", "Internal conflict within a country" },
            { "constitution", "Fundamental legal document" },
            { "imperialism", "Extending a nation's power" },
            { "enlightenment", "Intellectual and philosophical movement" },
            { "napoleon", "French military leader" },
            { "pyramid", "Ancient tomb structure" },
            { "inquisition", "Catholic investigation court" },
            { "armistice", "Agreement to stop fighting" },
            { "regime", "Governing system" },

            // Geography
            { "continent", "One of Earth's main landmasses" },
            { "archipelago", "A group of islands" },
            { "volcano", "A mountain that erupts" },
            { "glacier", "A slow-moving mass of ice" },
            { "peninsula", "Land surrounded by water on three sides" },
            { "savanna", "Grassy plain in tropical regions" },
            { "island", "Land surrounded by water" },
            { "delta", "Landform at a river mouth" },
            { "rainforest", "Dense forest in tropical area" },
            { "tundra", "Cold, treeless biome" },
            { "equator", "Imaginary line around the Earth" },
            { "latitude", "Distance north or south of the equator" },
            { "longitude", "Distance east or west of the Prime Meridian" },
            { "mountain", "High natural elevation of land" },
            { "desert", "Dry, barren region" },
            { "plateau", "Flat elevated landform" },
            { "canyon", "Deep valley with steep sides" },
            { "oasis", "Fertile land in a desert" },
            { "fjord", "Narrow sea inlet bordered by cliffs" },
            { "basin", "Low area drained by a river system" },

            // Mathematics
            { "algebra", "Math involving variables and equations" },
            { "geometry", "Math dealing with shapes and spaces" },
            { "calculus", "Math involving limits and change" },
            { "matrix", "Rectangular array of numbers" },
            { "vector", "Quantity with magnitude and direction" },
            { "integral", "Sum of infinite small parts" },
            { "derivative", "Rate of change in calculus" },
            { "logarithm", "Inverse of exponentiation" },
            { "equation", "Mathematical statement with '=' sign" },
            { "function", "Relation between input and output" },
            { "variable", "Symbol representing a number" },
            { "theorem", "Statement proven by logic" },
            { "probability", "Measure of chance" },
            { "fraction", "Part of a whole" },
            { "polygon", "Shape with many sides" },
            { "angle", "Formed by two rays" },
            { "radius", "Distance from center to edge of circle" },
            { "pi", "Ratio of circumference to diameter" },
            { "median", "Middle value in data" },
            { "divisor", "Number that divides another" },

            // General Culture
            { "cinema", "Art of making films" },
            { "literature", "Written works of artistic value" },
            { "fashion", "Popular clothing trends" },
            { "philosophy", "Study of fundamental questions" },
            { "painting", "Applying color to a surface" },
            { "theater", "Live performance art" },
            { "music", "Art of sound and rhythm" },
            { "opera", "Dramatic work set to music" },
            { "sculpture", "3D art made by shaping material" },
            { "mythology", "Collection of cultural myths" },
            { "festival", "Celebratory event" },
            { "language", "System of communication" },
            { "comedy", "Entertainment that provokes laughter" },
            { "culture", "Shared beliefs and practices" },
            { "journalism", "News reporting and writing" },
            { "poetry", "Literary art using rhythm and style" },
            { "media", "Means of mass communication" },
            { "internet", "Global network of computers" },
            { "tradition", "Customs passed through generations" },
            { "architecture", "Art of designing buildings" }
        };

        public Form2(string selectedCategory, int gameTime, string difficulty, string imageStyle)
        {
            InitializeComponent();
            category = selectedCategory;

            this.settingsGameTime = gameTime;

            timeLeft = gameTime;
            gameDifficulty = difficulty;
            this.imageStyle = imageStyle;
            InitializeGame();
            DisplaySettings();
        }

        private void DisplaySettings()
        {
            settingsLabel.Text = $"Time: 00:{timeLeft} - Category: {category} - Level: {gameDifficulty}";
        }
        
        

        private void InitializeGame()
        {
            Random random = new Random();
            if (categoryQuestions.ContainsKey(category))
            {
                List<Question> filteredQuestions = categoryQuestions[category]
                    .Where(q => q.Difficulty == gameDifficulty)
                    .ToList();

                if (filteredQuestions.Count > 0)
                {
                    selectedWord = filteredQuestions[random.Next(filteredQuestions.Count)].Word;
                }
                else
                {
                   
                    selectedWord = categoryQuestions[category][random.Next(categoryQuestions[category].Count)].Word;
                    MessageBox.Show($"No words found for '{gameDifficulty}' difficulty in '{category}'. A random word will be chosen.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            else
            {
                selectedWord = "unknown";
            }

            hiddenWord = new string('_', selectedWord.Length);
            wordLengthLabel.Text = "Word Length: " + selectedWord.Length;
            UpdateHiddenWord('_');
            scoreLabel.Text = "Score: " + score + " P";
            UpdateDisplayImage();
            guessedLettersLabel.Text = "Incorrect Guesses: ";
            this.BackColor = DefaultBackColor;
            gameOver = false;

            if (gameTimer == null)
            {
                gameTimer = new Timer();
                gameTimer.Interval = 1000;
                gameTimer.Tick += GameTimer_Tick;
            }
            gameTimer.Start();

            timeLabel.Text = "Time left: " + timeLeft + "s";
        }

        


        private void GameTimer_Tick(object sender, EventArgs e)
        {
            if (!gameOver)
            {
                timeLeft--;
                timeLabel.Text = "Time left: " + timeLeft + "s";

                if (timeLeft <= 0)
                {
                    gameTimer.Stop();
                    gameOver = true;
                    this.BackColor = Color.Red;
                    MessageBox.Show("Time's up! Game Over.", "Time Out", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    
                    guessButton.Enabled = false;
                    hiddenWordLabel.Text = selectedWord; 
                }
            }
        }

        private void ResetGame()
        {
            this.BackColor = DefaultBackColor;
            score = 100;
            incorrectGuesses = 0;
            timeLeft = this.settingsGameTime;
            
            correctGuesses.Clear();
            incorrectGuessesList.Clear();
            guessedLetters.Clear();
            guessButton.Enabled = true;

            gameOver = false;

            if (gameTimer != null)
            {
                gameTimer.Stop();
            }

            InitializeGame();
        }



        private void UpdateHiddenWord(char guessedLetter)
        {
            StringBuilder sb = new StringBuilder();

            for (int i = 0; i < selectedWord.Length; i++)
            {
                if (correctGuesses.Contains(selectedWord[i]))
                {
                    sb.Append(selectedWord[i]);
                }
                else
                {
                    sb.Append('_');
                }

                if (i < selectedWord.Length - 1)
                {
                    sb.Append(' ');
                }
            }

            hiddenWord = sb.ToString();
            if (hiddenWordLabel != null) hiddenWordLabel.Text = hiddenWord;
        }
        private void UpdateDisplayImage()
        {
            try
            {
                System.Drawing.Image image = null;
                if (this.imageStyle == "Hangman")
                {
                    switch (incorrectGuesses)
                    {
                        case 0: image = ImageFromByteArray(Properties.Resources.cover_2); break;
                        case 1: image = ImageFromByteArray(Properties.Resources.man_01); break;
                        case 2: image = ImageFromByteArray(Properties.Resources.man_02); break;
                        case 3: image = ImageFromByteArray(Properties.Resources.man_03); break;
                        case 4: image = ImageFromByteArray(Properties.Resources.man_04); break;
                        case 5: image = ImageFromByteArray(Properties.Resources.man_05); break;
                        case 6: image = ImageFromByteArray(Properties.Resources.man_06); break;
                        case 7: image = ImageFromByteArray(Properties.Resources.man_07); break;
                        case 8: image = ImageFromByteArray(Properties.Resources.man_08); break;
                        case 9: image = ImageFromByteArray(Properties.Resources.man_09); break;
                        case 10: image = ImageFromByteArray(Properties.Resources.man_10); break;
                        default: image = null; break;
                    }
                }
                else if (this.imageStyle == "Falling Flowers")
                {
                    // Load your flower images based on incorrect guesses
                    switch (incorrectGuesses)
                    {
                        case 0: image = ImageFromByteArray(Properties.Resources.flower_11); break;
                        case 1: image = ImageFromByteArray(Properties.Resources.flower_12); break;
                        case 2: image = ImageFromByteArray(Properties.Resources.flower_13); break;
                        case 3: image = ImageFromByteArray(Properties.Resources.flower_14); break;
                        case 4: image = ImageFromByteArray(Properties.Resources.flower_15); break;
                        case 5: image = ImageFromByteArray(Properties.Resources.flower_16); break;
                        case 6: image = ImageFromByteArray(Properties.Resources.flower_17); break;
                        case 7: image = ImageFromByteArray(Properties.Resources.flower_18); break;
                        case 8: image = ImageFromByteArray(Properties.Resources.flower_19); break;
                        case 9: image = ImageFromByteArray(Properties.Resources.flower_20); break;
                        case 10: image = null; break;
                        default: image = null; break;

                    }
                }
                else if (this.imageStyle == "Heart and Swords")
                {
                    switch (incorrectGuesses)
                    {
                        case 0: image = Properties.Resources.h1; break;
                        case 1: image = Properties.Resources.h2; break;
                        case 2: image = Properties.Resources.h3; break;
                        case 3: image = Properties.Resources.h4; break;
                        case 4: image = Properties.Resources.h5; break;
                        case 5: image = Properties.Resources.h6; break;
                        case 6: image = Properties.Resources.h7; break;
                        case 7: image = Properties.Resources.h8; break;
                        case 8: image = Properties.Resources.h9; break;
                        case 9: image = Properties.Resources.h10; break;
                    }



                }
                if (hangmanPictureBox != null) 
                {
                    hangmanPictureBox.Image = image;
                    hangmanPictureBox.Invalidate(); 
                }
                else
                {
                    MessageBox.Show("Error: hangmanPictureBox is not initialized.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading image: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        private System.Drawing.Image ImageFromByteArray(byte[] byteArray)
        {
            using (MemoryStream ms = new MemoryStream(byteArray))
            {
                try
                {
                    return System.Drawing.Image.FromStream(ms);
                }
                catch (Exception)
                {
                    return null;
                }
            }
        }
        private void CheckWinLose()
        {
            if (!hiddenWord.Contains('_'))
            {
                gameOver = true; 
                gameTimer.Stop();
                this.BackColor = Color.Green;
                MessageBox.Show("Congratulations! You won!", "You Win", MessageBoxButtons.OK, MessageBoxIcon.Information);

                guessButton.Enabled = false;
            }
            else if (incorrectGuesses >= maxIncorrectGuesses)
            {
                gameOver = true; 
                gameTimer.Stop();
                this.BackColor = Color.Red;
                MessageBox.Show("Game Over! You lost. The word was: " + selectedWord, "You Lose", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                guessButton.Enabled = false;
                hiddenWordLabel.Text = selectedWord;
            }
        }

        private void UpdateScore()
        {
            score -= 10;
            scoreLabel.Text = "Score: " + score + " Points";
        }

        private List<char> correctGuesses = new List<char>();
        private List<char> incorrectGuessesList = new List<char>();


        private void guessButton_Click(object sender, EventArgs e)
        {
            if (gameOver)
            {
                return;
            }

            char guessedLetter;
            if (guessTextBox.Text.Length != 1 || !char.IsLetter(guessTextBox.Text[0]))
            {
                MessageBox.Show("Please enter a single letter.", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                guessTextBox.Clear();
                return;
            }

            guessedLetter = char.ToLower(guessTextBox.Text[0]);
            guessTextBox.Clear();

            if (correctGuesses.Contains(guessedLetter) || incorrectGuessesList.Contains(guessedLetter))
            {
                MessageBox.Show("You've already guessed that letter.", "Duplicate Guess", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (selectedWord.Contains(guessedLetter))
            {
                correctGuesses.Add(guessedLetter);
                UpdateHiddenWord(guessedLetter);


            }
            else
            {
                incorrectGuessesList.Add(guessedLetter);
                incorrectGuesses++;
                UpdateDisplayImage();
                UpdateScore();
            }

            guessedLettersLabel.Text = "Incorrect Guesses: " + string.Join(", ", incorrectGuessesList);

            CheckWinLose();

        }

        private void endButton_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Do you want to reset the game?", "Reset Game", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                ResetGame();
            }
        }
       
        private void helpButton_Click(object sender, EventArgs e)
        {
            if (wordClues.ContainsKey(selectedWord))
            {
                MessageBox.Show("Clue: " + wordClues[selectedWord], "Clue", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("No clue available for this word.", "Clue", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

       

 
    }
}
