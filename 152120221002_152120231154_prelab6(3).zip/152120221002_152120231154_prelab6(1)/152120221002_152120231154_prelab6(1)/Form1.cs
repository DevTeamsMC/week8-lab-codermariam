﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _152120221002_152120231154_prelab6_1_
{
    public partial class Form1 : Form
    {
        private int gameTime = 60; 
        private string difficulty = "Medium"; 
        private string imageStyle = "Hangman"; 
        private bool settingsSaved = false;
        public Form1()
        {
            InitializeComponent();
            LoadCategories();
            
        }

        private void LoadCategories()
        {
            comboBoxCategories.Items.AddRange(new string[]
            {
                "History",
                "Geography",
                "Mathematics" ,
                "General Culture"
            });
            comboBoxCategories.SelectedIndex = 0;
        }
     
        private void button1_Click(object sender, EventArgs e)
        {
            if (!settingsSaved)
            {
                MessageBox.Show("Please set your game preferences in the Settings before starting.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (comboBoxCategories.SelectedItem == null)
            {
                MessageBox.Show("Please select a topic category.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string selectedCategory = comboBoxCategories.SelectedItem.ToString();
            
            Form2 gameForm = new Form2(selectedCategory, gameTime, difficulty, imageStyle);
            this.Hide();
            gameForm.ShowDialog();
            this.Close();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }


        private void settingsButton_Click(object sender, EventArgs e)
        {
            SettingsForm settingsForm = new SettingsForm();
            if (settingsForm.ShowDialog() == DialogResult.OK)
            {
                
                gameTime = settingsForm.GameTime; 
                difficulty = settingsForm.Difficulty; 
                imageStyle = settingsForm.ImageStyle;
                settingsSaved = true;
                
            }
        }

    }
}
